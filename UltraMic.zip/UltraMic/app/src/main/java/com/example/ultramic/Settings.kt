package com.example.ultramic

import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.log10
import kotlin.math.pow

/** All user-controllable parameters. Sliders are normalized 0..1 unless noted. */
data class Settings(
    val noiseSuppress: Boolean = true,      // swNoiseSuppress
    val echoCancel: Boolean = true,         // swEchoCancel
    val autoGain: Boolean = false,          // swAutoGain
    val normalizer: Boolean = false,        // software loudness normalizer
    val micGain: Float = 0f,                // 0..1 -> 1x .. 50,000x (log)
    val volumeBoost: Float = 0f,            // 0..1 -> 1x .. 1,000x (log)
    val dynBass: Float = 0f,                // sliderDynBass
    val drc: Float = 0f,                    // dynamic range compression amount
    val transient: Float = 0f,              // transient (peak spike) control amount
    val eightD: Boolean = false,
    val eightDDepth: Float = 0.7f,          // sliderEightDDepth
    val eightDRate: Float = 0.15f,          // sliderEightDRate -> 0.05..3 Hz
    val eq: List<Float> = List(5) { 0f },   // dB, -15..+15
    val ceiling: Float = 0.5f,              // output ceiling (safety limiter level)
    val mute: Boolean = false,
    val mobileView: Boolean = true
)

object EngineHub {
    val settings = MutableStateFlow(Settings())
    val inLevel = MutableStateFlow(0f)
    val outLevel = MutableStateFlow(0f)
    val running = MutableStateFlow(false)
    val latencyMs = MutableStateFlow(0f)
}

const val MAX_MIC_GAIN = 50_000f
const val MAX_VOL_BOOST = 1_000f

fun logGain(v: Float, max: Float): Float = 10f.pow(v * log10(max))
