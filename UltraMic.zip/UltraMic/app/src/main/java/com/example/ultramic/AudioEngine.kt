package com.example.ultramic

import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Process
import kotlin.math.*

/**
 * Real-time mic -> DSP -> speaker/headphone pipeline.
 * Uses AudioRecord + AudioTrack in LOW_LATENCY mode with device-native rate and burst size.
 *
 * Chain: DC-block -> normalizer -> mic gain -> 5-band EQ + dynamic bass -> DRC -> transient
 *        -> volume boost -> 8D -> soft limiter / hard ceiling.
 */
class AudioEngine(private val ctx: Context) {
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "UltraMicAudio").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(800)
        thread = null
    }

    private fun loop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val sr = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        val burst = am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256
        val fs = sr.toFloat()

        val minRec = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val record = AudioRecord.Builder()
            .setAudioSource(MediaRecorder.AudioSource.MIC)
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
            )
            .setBufferSizeInBytes(max(minRec, burst * 2 * 2))
            .build()

        val minTrack = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setBufferSizeInBytes(max(minTrack, burst * 4 * 2))
            .build()

        // Platform effects (availability varies by device)
        val ns = if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(record.audioSessionId) else null
        val aec = if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(record.audioSessionId) else null
        val agc = if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(record.audioSessionId) else null

        EngineHub.latencyMs.value =
            (record.bufferSizeInFrames + track.bufferSizeInFrames) * 1000f / fs

        // DSP objects
        val dc = Biquad().apply { highPass(fs, 20f) }
        val eqBands = Array(5) { Biquad() }
        val bass = Biquad()
        val drcDyn = Dynamics(fs, 5f, 150f)
        val transDyn = Dynamics(fs, 0.1f, 40f)
        val norm = Normalizer(fs)
        val spatial = EightD(fs)
        val st = FloatArray(2)

        var lastEq: List<Float>? = null
        var lastBass = -1f
        var lastNs = false; var lastAec = false; var lastAgc = false

        val inBuf = ShortArray(burst)
        val outBuf = ShortArray(burst * 2)

        record.startRecording()
        track.play()

        try {
            while (running) {
                val s = EngineHub.settings.value

                // toggles applied live
                if (s.noiseSuppress != lastNs) { ns?.enabled = s.noiseSuppress; lastNs = s.noiseSuppress }
                if (s.echoCancel != lastAec) { aec?.enabled = s.echoCancel; lastAec = s.echoCancel }
                if (s.autoGain != lastAgc) { agc?.enabled = s.autoGain; lastAgc = s.autoGain }

                if (s.eq != lastEq) {
                    eqBands[0].lowShelf(fs, 80f, s.eq[0])
                    eqBands[1].peaking(fs, 250f, 1.0f, s.eq[1])
                    eqBands[2].peaking(fs, 1000f, 1.0f, s.eq[2])
                    eqBands[3].peaking(fs, 4000f, 1.0f, s.eq[3])
                    eqBands[4].highShelf(fs, 10000f, s.eq[4])
                    lastEq = s.eq
                }
                if (s.dynBass != lastBass) { bass.lowShelf(fs, 120f, s.dynBass * 12f); lastBass = s.dynBass }

                val n = record.read(inBuf, 0, burst)
                if (n <= 0) continue

                val micGain = logGain(s.micGain, MAX_MIC_GAIN)
                val volBoost = logGain(s.volumeBoost, MAX_VOL_BOOST)
                val drcThr = 10f.pow((-10f - 30f * s.drc) / 20f)
                val drcRatio = 2f + 8f * s.drc
                val drcMakeup = 10f.pow((10f + 30f * s.drc) * 0.5f / 20f)
                val transThr = 0.8f - 0.7f * s.transient
                val rateHz = 0.05f + s.eightDRate * 2.95f
                val ceiling = s.ceiling.coerceIn(0.05f, 0.98f)

                var inPeak = 0f; var outPeak = 0f
                for (i in 0 until n) {
                    var x = inBuf[i] / 32768f
                    inPeak = max(inPeak, abs(x))
                    x = dc.process(x)
                    if (s.normalizer) x = norm.process(x)
                    x = (x * micGain).coerceIn(-1e6f, 1e6f)
                    for (b in eqBands) x = b.process(x)
                    if (s.dynBass > 0f) x = bass.process(x)
                    if (s.drc > 0f) x = drcDyn.process(x, drcThr, drcRatio) * drcMakeup
                    if (s.transient > 0f) x = transDyn.process(x, transThr, 20f)
                    x = (x * volBoost).coerceIn(-1e6f, 1e6f)

                    var l = x; var r = x
                    if (s.eightD) { spatial.process(x, s.eightDDepth, rateHz, st); l = st[0]; r = st[1] }

                    // soft limiter (tanh) scaled to ceiling, then hard clamp
                    l = ceiling * tanh(l / ceiling); r = ceiling * tanh(r / ceiling)
                    if (!l.isFinite()) l = 0f
                    if (!r.isFinite()) r = 0f
                    if (s.mute) { l = 0f; r = 0f }
                    outPeak = max(outPeak, max(abs(l), abs(r)))
                    outBuf[2 * i] = (l.coerceIn(-0.99f, 0.99f) * 32767f).toInt().toShort()
                    outBuf[2 * i + 1] = (r.coerceIn(-0.99f, 0.99f) * 32767f).toInt().toShort()
                }
                track.write(outBuf, 0, n * 2)

                // meters with simple decay
                EngineHub.inLevel.value = max(inPeak, EngineHub.inLevel.value * 0.85f)
                EngineHub.outLevel.value = max(outPeak, EngineHub.outLevel.value * 0.85f)
            }
        } finally {
            runCatching { record.stop() }
            runCatching { track.stop() }
            record.release(); track.release()
            ns?.release(); aec?.release(); agc?.release()
            EngineHub.inLevel.value = 0f; EngineHub.outLevel.value = 0f
        }
    }
}
