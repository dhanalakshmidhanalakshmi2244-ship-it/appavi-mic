package com.example.ultramic

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.update

private val Violet = Color(0xFFA855F7)
private val DeepViolet = Color(0xFF6D28D9)
private val Panel = Color(0xFF120A1F)
private val Ink = Color(0xFF05020A)

@Composable
fun UltraMicApp(onStart: () -> Unit, onStop: () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet, onPrimary = Color.Black, background = Ink, surface = Panel,
            onBackground = Color(0xFFEDE3FF), onSurface = Color(0xFFEDE3FF)
        )
    ) {
        val s by EngineHub.settings.collectAsState()
        val running by EngineHub.running.collectAsState()
        val inL by EngineHub.inLevel.collectAsState()
        val outL by EngineHub.outLevel.collectAsState()
        val lat by EngineHub.latencyMs.collectAsState()
        fun upd(f: (Settings) -> Settings) = EngineHub.settings.update(f)

        Box(
            Modifier.fillMaxSize().background(Ink).systemBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                Modifier
                    .then(if (s.mobileView) Modifier.widthIn(max = 430.dp) else Modifier)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("ULTRA MIC", fontSize = 28.sp, color = Violet)
                Text(
                    "Use wired/Bluetooth headphones. Speaker output + high gain = feedback and loud noise.",
                    fontSize = 12.sp, color = Color(0xFFB9A4D6)
                )

                Button(
                    onClick = { if (running) onStop() else onStart() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = if (running) DeepViolet else Violet)
                ) { Text(if (running) "STOP ENGINE" else "START ENGINE") }

                Card("Diagnostics") {
                    Meter("Mic in", inL)
                    Meter("Output", outL)
                    Text("Est. buffer latency: %.1f ms".format(lat), fontSize = 12.sp)
                    ToggleRow("Mute output", s.mute, "swMute") { v -> upd { it.copy(mute = v) } }
                    LabeledSlider("Output ceiling", s.ceiling, "%.0f%%".format(s.ceiling * 100), 0.05f..0.98f, "sliderCeiling") { v -> upd { it.copy(ceiling = v) } }
                }

                Card("Voice processing") {
                    ToggleRow("Noise suppression", s.noiseSuppress, "swNoiseSuppress") { v -> upd { it.copy(noiseSuppress = v) } }
                    ToggleRow("Echo cancellation", s.echoCancel, "swEchoCancel") { v -> upd { it.copy(echoCancel = v) } }
                    ToggleRow("Auto gain control", s.autoGain, "swAutoGain") { v -> upd { it.copy(autoGain = v) } }
                    ToggleRow("Loudness normalizer", s.normalizer, "swNormalizer") { v -> upd { it.copy(normalizer = v) } }
                }

                Card("Gain boost") {
                    LabeledSlider("Mic gain", s.micGain, "x%,.0f".format(logGain(s.micGain, MAX_MIC_GAIN)), 0f..1f, "sliderMicGain") { v -> upd { it.copy(micGain = v) } }
                    LabeledSlider("Volume boost", s.volumeBoost, "x%,.0f".format(logGain(s.volumeBoost, MAX_VOL_BOOST)), 0f..1f, "sliderVolBoost") { v -> upd { it.copy(volumeBoost = v) } }
                    LabeledSlider("Dynamic range compression", s.drc, "%.0f%%".format(s.drc * 100), 0f..1f, "sliderDrc") { v -> upd { it.copy(drc = v) } }
                    LabeledSlider("Transient control", s.transient, "%.0f%%".format(s.transient * 100), 0f..1f, "sliderTransient") { v -> upd { it.copy(transient = v) } }
                    Text("Tip: enable compression when using high gain to avoid clipping.", fontSize = 11.sp, color = Color(0xFFB9A4D6))
                }

                Card("Bass & 5-band equalizer") {
                    LabeledSlider("Dynamic bass", s.dynBass, "+%.1f dB".format(s.dynBass * 12f), 0f..1f, "sliderDynBass") { v -> upd { it.copy(dynBass = v) } }
                    val names = listOf("Low bass", "Mid bass", "Midrange", "Upper mid / presence", "Treble")
                    names.forEachIndexed { i, name ->
                        LabeledSlider(name, s.eq[i], "%+.1f dB".format(s.eq[i]), -15f..15f, "sliderEq$i") { v ->
                            upd { cur -> cur.copy(eq = cur.eq.toMutableList().also { l -> l[i] = v }) }
                        }
                    }
                }

                Card("8D spatial audio") {
                    ToggleRow("Enable 8D", s.eightD, "swEightD") { v -> upd { it.copy(eightD = v) } }
                    LabeledSlider("Depth", s.eightDDepth, "%.0f%%".format(s.eightDDepth * 100), 0f..1f, "sliderEightDDepth") { v -> upd { it.copy(eightDDepth = v) } }
                    LabeledSlider("Rotation speed", s.eightDRate, "%.2f Hz".format(0.05f + s.eightDRate * 2.95f), 0f..1f, "sliderEightDRate") { v -> upd { it.copy(eightDRate = v) } }
                }

                Card("App") {
                    ToggleRow("Mobile view mode", s.mobileView, "swMobileView") { v -> upd { it.copy(mobileView = v) } }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun Card(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .shadow(14.dp, RoundedCornerShape(18.dp), ambientColor = Violet, spotColor = Violet)
            .background(Panel, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(title, color = Violet, fontSize = 15.sp)
        content()
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, tag: String, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange, Modifier.testTag(tag))
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float, valueText: String, range: ClosedFloatingPointRange<Float>,
    tag: String, onChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, Modifier.weight(1f), fontSize = 13.sp)
            Text(valueText, fontSize = 13.sp, color = Violet)
        }
        Slider(value, onChange, Modifier.testTag(tag), valueRange = range)
    }
}

@Composable
private fun Meter(label: String, level: Float) {
    Column {
        Text(label, fontSize = 12.sp)
        LinearProgressIndicator(
            progress = { level.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp),
            color = if (level > 0.9f) Color(0xFFFF4D6D) else Violet,
            trackColor = Color(0xFF241638)
        )
    }
}
