package com.example.ultramic

import kotlin.math.*

/** RBJ cookbook biquad (transposed direct form II). */
class Biquad {
    private var b0 = 1.0; private var b1 = 0.0; private var b2 = 0.0
    private var a1 = 0.0; private var a2 = 0.0
    private var z1 = 0.0; private var z2 = 0.0

    fun process(x: Float): Float {
        val xd = x.toDouble()
        val y = b0 * xd + z1
        z1 = b1 * xd - a1 * y + z2
        z2 = b2 * xd - a2 * y
        return y.toFloat()
    }

    private fun set(nb0: Double, nb1: Double, nb2: Double, na0: Double, na1: Double, na2: Double) {
        b0 = nb0 / na0; b1 = nb1 / na0; b2 = nb2 / na0; a1 = na1 / na0; a2 = na2 / na0
    }

    fun peaking(fs: Float, f0: Float, q: Float, gainDb: Float) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2 * PI * f0 / fs; val c = cos(w0); val alpha = sin(w0) / (2 * q)
        set(1 + alpha * a, -2 * c, 1 - alpha * a, 1 + alpha / a, -2 * c, 1 - alpha / a)
    }

    fun lowShelf(fs: Float, f0: Float, gainDb: Float) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2 * PI * f0 / fs; val c = cos(w0)
        val sq = 2 * sqrt(a) * (sin(w0) / 2 * sqrt(2.0))
        set(
            a * ((a + 1) - (a - 1) * c + sq), 2 * a * ((a - 1) - (a + 1) * c), a * ((a + 1) - (a - 1) * c - sq),
            (a + 1) + (a - 1) * c + sq, -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - sq
        )
    }

    fun highShelf(fs: Float, f0: Float, gainDb: Float) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2 * PI * f0 / fs; val c = cos(w0)
        val sq = 2 * sqrt(a) * (sin(w0) / 2 * sqrt(2.0))
        set(
            a * ((a + 1) + (a - 1) * c + sq), -2 * a * ((a - 1) + (a + 1) * c), a * ((a + 1) + (a - 1) * c - sq),
            (a + 1) - (a - 1) * c + sq, 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - sq
        )
    }

    fun highPass(fs: Float, f0: Float, q: Float = 0.707f) {
        val w0 = 2 * PI * f0 / fs; val c = cos(w0); val alpha = sin(w0) / (2 * q)
        set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + alpha, -2 * c, 1 - alpha)
    }
}

/** Feed-forward compressor/limiter with peak detector. Used for both DRC and transient control. */
class Dynamics(fs: Float, attackMs: Float, releaseMs: Float) {
    private val attCoef = exp(-1f / (0.001f * attackMs * fs))
    private val relCoef = exp(-1f / (0.001f * releaseMs * fs))
    private var env = 0f
    private var gain = 1f

    fun process(x: Float, threshold: Float, ratio: Float): Float {
        val a = abs(x)
        env = max(a, env * relCoef)
        val target = if (env > threshold) (env / threshold).pow(1f / ratio - 1f) else 1f
        gain = if (target < gain) attCoef * gain + (1 - attCoef) * target
        else relCoef * gain + (1 - relCoef) * target
        return x * gain
    }
}

/** Slow software loudness normalizer (RMS tracker -> target level). */
class Normalizer(private val fs: Float) {
    private var ms = 0f
    private var gain = 1f
    private val rmsCoef = exp(-1f / (0.3f * fs))
    private val gainCoef = exp(-1f / (0.5f * fs))

    fun process(x: Float, target: Float = 0.1f): Float {
        ms = rmsCoef * ms + (1 - rmsCoef) * x * x
        val rms = sqrt(ms)
        if (rms > 1e-4f) { // gate: hold gain during near-silence so noise isn't pumped up
            val t = (target / rms).coerceIn(0.1f, 1000f)
            gain = gainCoef * gain + (1 - gainCoef) * t
        }
        return x * gain
    }
}

/**
 * 8D effect: source orbits the head. Uses equal-power panning, interaural time difference
 * (up to ~0.66 ms), and head-shadow low-pass on the far ear / rear hemisphere.
 */
class EightD(private val fs: Float) {
    private val mask = 1023
    private val buf = FloatArray(mask + 1)
    private val maxDelay = 0.00066f * fs
    private var w = 0
    private var phase = 0f
    private var lpL = 0f
    private var lpR = 0f

    private fun tap(d: Float): Float {
        val i = floor(d).toInt(); val f = d - i
        val a = buf[(w - i) and mask]; val b = buf[(w - i - 1) and mask]
        return a + (b - a) * f
    }

    /** Returns L in out[0], R in out[1]. */
    fun process(x: Float, depth: Float, rateHz: Float, out: FloatArray) {
        buf[w and mask] = x
        phase += (2.0 * PI * rateHz / fs).toFloat()
        if (phase > 2 * PI.toFloat()) phase -= 2 * PI.toFloat()
        val p = depth * sin(phase)          // -1 (left) .. +1 (right)
        val rear = max(0f, -cos(phase)) * depth
        val ang = (p + 1f) * (PI.toFloat() / 4f)
        val gL = cos(ang) * 1.41421356f
        val gR = sin(ang) * 1.41421356f
        val l = tap(max(0f, p) * maxDelay) * gL
        val r = tap(max(0f, -p) * maxDelay) * gR
        val cL = (1f - 0.75f * (max(0f, p) * 0.6f + rear * 0.6f)).coerceIn(0.05f, 1f)
        val cR = (1f - 0.75f * (max(0f, -p) * 0.6f + rear * 0.6f)).coerceIn(0.05f, 1f)
        lpL += cL * (l - lpL)
        lpR += cR * (r - lpR)
        out[0] = lpL; out[1] = lpR
        w = (w + 1) and mask
    }
}
